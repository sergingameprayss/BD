#ifndef FD
#define FD

#define bool int
#define true 1
#define false 0

#define MAX_ATTRS 26
#define MAX_FDS 1000

#define ERROR 1
#define OK 0


typedef struct fd {
    bool lhs[MAX_ATTRS];
    bool rhs[MAX_ATTRS];
} fd_t;

typedef struct fd_set {
    bool u[MAX_ATTRS];
    fd_t fds[MAX_FDS]; //maybe a maximum of 1000?
    int size;
} fd_set_t;

void init_fd_set (fd_set_t *sys);

int closure (const fd_set_t *sys, const char *attr, bool *attr_clos);

int mincover(const fd_set_t *sys, fd_set_t *fd_mincover);

int candidate_keys(const fd_set_t *sys, bool keys[][MAX_ATTRS]);

int normal_form(const fd_set_t *sys);

void print_set (const char *attr, bool *s, int s_size);

void print_attrs(const bool *attrs);

void print_fd(fd_set_t *sys);

void print_fd_set (fd_set_t *sys);

void print_keys(bool keys[][MAX_ATTRS], int num_keys);

#endif //FD